Cart & Crown asset upload pack

Contents:
- assets/ui/crests: crest sheet + split Human / Elf / Orc crest PNGs
- assets/campaign/missions: mission art sheet + 6 split mission scene PNGs
- assets/units/human: human unit icon sheet, recruit sheet, militia sheet, and split human unit icons
- assets/units/elf: elf unit icon sheet + split unit icons
- assets/units/orc: orc unit icon sheet + split unit icons

Suggested next step after upload:
1. Commit these files under your repo assets folder.
2. Wire the crest PNGs into save select / kingdom / campaign headers.
3. Wire mission_01..06 into the campaign mission cards.
4. Use human_recruit_sheet.png and human_militia_sheet.png as separate visuals for Recruit and Militia.
5. Use the split unit icons for per-unit UI cards, lists and roster slots.
