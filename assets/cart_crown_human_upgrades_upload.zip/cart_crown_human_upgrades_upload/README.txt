Cart & Crown human upgraded unit pass

Folder: assets/units/human_upgrades/

Included files:
- longbowman.png
- marksman.png
- greatswordsman.png
- champion.png
- pikeman.png
- royal_guard.png
- heavy_cavalry.png
- lancer.png
- mounted_archer.png
- field_medic.png
- field_chaplain.png
- banner_captain.png
- siege_engineer.png
- human_upgrades_sheet.png

Recommended wiring target classes:
Longbowman, Marksman, Greatswordsman, Champion, Pikeman, Royal Guard, Heavy Cavalry, Lancer, Mounted Archer, Field Medic, Field Chaplain, Banner Captain, Siege Engineer.
