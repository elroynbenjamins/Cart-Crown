Cart & Crown Human base roster visual pack

Folder: assets/units/human_base/

Included archetype files:
- spearman.png
- swordsman.png
- archer.png
- crossbowman.png
- scout.png
- shield_infantry.png
- cavalryman.png
- halberdier.png
- human_base_sheet.png

Recommended mapping:
Spearman -> spearman
Shield Spearman -> spearman or shield_infantry depending desired identity
Swordsman -> swordsman
Archer -> archer
Ranger -> scout or archer depending desired direction
Border Ranger -> scout
Crossbowman -> crossbowman
Scout -> scout
Shield Infantry -> shield_infantry
Scout Rider -> cavalryman
Cavalryman -> cavalryman
Halberdier -> halberdier
Man-at-Arms -> halberdier or swordsman depending desired direction
