# Imports the approved five Iron Hills PNGs and, with -Publish, commits them
# to the existing artwork PR feature branch on GitHub.
# Example: .\publish_iron_hills_assets.ps1 -RepoPath 'C:\src\Cart-Crown' -Publish
param(
  [Parameter(Mandatory=$true)][string]$RepoPath,
  [switch]$Publish
)
$ErrorActionPreference = 'Stop'
$branch = 'feature/iron-hills-five-mission-art-20261015'
$root = (Resolve-Path $RepoPath).Path
$src = Join-Path $PSScriptRoot 'assets\campaign\missions'
$dest = Join-Path $root 'assets\campaign\missions'
if (-not (Test-Path (Join-Path $root 'src\ui\humanCampaignMissionArt.ts'))) { throw "Not a Cart-Crown checkout: $root" }
if (-not (Test-Path (Join-Path $src 'iron_hills_muster.png'))) { throw 'Extract the entire zip archive first, retaining folders.' }
Push-Location $root
try {
  if ($Publish) {
    $dirty = & git status --porcelain
    if ($LASTEXITCODE -ne 0) { throw 'git status failed.' }
    if ($dirty) { throw 'Working tree is not clean. Commit or stash your changes before using -Publish.' }
    & git fetch origin $branch
    if ($LASTEXITCODE -ne 0) { throw 'Could not fetch the feature branch.' }
    & git switch $branch 2>$null
    if ($LASTEXITCODE -ne 0) {
      & git switch -c $branch --track "origin/$branch"
      if ($LASTEXITCODE -ne 0) { throw 'Could not switch to the feature branch.' }
    }
  } else {
    Write-Host 'Note: assets installed locally; use -Publish to commit and push to the GitHub PR branch.'
  }
  New-Item -ItemType Directory -Path $dest -Force | Out-Null
  $manifest = Get-Content (Join-Path $PSScriptRoot 'asset_manifest.json') -Raw | ConvertFrom-Json
  $names = @('iron_hills_muster','iron_hills_smithy','iron_hills_road','iron_hills_iron_line','iron_hills_provost_boss')
  foreach ($name in $names) {
    $relative = "assets/campaign/missions/$name.png"
    $from = Join-Path $src "$name.png"
    $to = Join-Path $dest "$name.png"
    if (-not (Test-Path $from)) { throw "Missing from package: $from" }
    $hash = (Get-FileHash $from -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne $manifest.files.$relative.sha256) { throw "SHA256 mismatch: $name" }
    Copy-Item -LiteralPath $from -Destination $to -Force
    Write-Host "Verified $name.png"
  }
  if ($Publish) {
    & npm run campaign-art:check
    if ($LASTEXITCODE -ne 0) { throw 'Campaign art check failed. Files remain local; no commit was made.' }
    & npm run art:check
    if ($LASTEXITCODE -ne 0) { throw 'Art check failed. Files remain local; no commit was made.' }
    & npm run typecheck
    if ($LASTEXITCODE -ne 0) { throw 'Typecheck failed. Files remain local; no commit was made.' }
    & git add -- 'assets/campaign/missions/iron_hills_muster.png' 'assets/campaign/missions/iron_hills_smithy.png' 'assets/campaign/missions/iron_hills_road.png' 'assets/campaign/missions/iron_hills_iron_line.png' 'assets/campaign/missions/iron_hills_provost_boss.png'
    if ($LASTEXITCODE -ne 0) { throw 'git add failed.' }
    & git commit -m 'Ship five approved Iron Hills Chapter 2 paintings'
    if ($LASTEXITCODE -ne 0) { throw 'git commit failed.' }
    & git push -u origin $branch
    if ($LASTEXITCODE -ne 0) { throw 'Git push failed. Local commit is intact; rerun git push.' }
    Write-Host 'Published five Iron Hills PNGs to PR #176. Watch GitHub Actions before merging.'
  } else {
    Write-Host 'Installed locally. The feature-branch source changes must also be checked out to build.'
  }
} finally {
  Pop-Location
}
