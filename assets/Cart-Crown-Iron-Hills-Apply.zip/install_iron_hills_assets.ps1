# Apply the five approved Iron Hills PNGs to your existing Cart-Crown checkout.
# Usage:  .\install_iron_hills_assets.ps1 -RepoPath "C:\src\Cart-Crown"
param([Parameter(Mandatory=$true)][string]$RepoPath)
$ErrorActionPreference = "Stop"
$root = (Resolve-Path $RepoPath).Path
if (-not (Test-Path (Join-Path $root "src\ui\humanCampaignMissionArt.ts"))) { throw "Not a Cart-Crown project: $root" }
$src = Join-Path $PSScriptRoot "assets\campaign\missions"
$dest = Join-Path $root "assets\campaign\missions"
New-Item -ItemType Directory -Path $dest -Force | Out-Null
$names = @("iron_hills_muster", "iron_hills_smithy", "iron_hills_road", "iron_hills_iron_line", "iron_hills_provost_boss")
foreach ($name in $names) {
  $from = Join-Path $src "$name.png"
  $to = Join-Path $dest "$name.png"
  if (-not (Test-Path $from)) { throw "Missing from package: $from" }
  Copy-Item -LiteralPath $from -Destination $to -Force
  $size = (Get-Item $to).Length
  if ($size -ge 900000) { throw "Image too large: $name ($size bytes)" }
  Write-Host "Installed: $name.png ($size bytes)"
}
Write-Host "Done. In your Cart-Crown repository, run:"
Write-Host "  npm run campaign-art:check"
Write-Host "  npm run art:check"
Write-Host "  npm run typecheck"
Write-Host "  git add assets/campaign/missions/iron_hills_*.png"
Write-Host "  git commit -m 'Ship five Iron Hills chapter artwork scenes'"
Write-Host "  git push"
