Cart & Crown / Human Chapter 2 — Iron Hills artwork

Five approved 724 x 362 RGB PNGs with pre-wired scene keys on GitHub PR #176.

ONE-COMMAND INSTALL + PUBLISH (Windows PowerShell, in EXTRACTED zip folder):
  .\publish_iron_hills_assets.ps1 -RepoPath 'C:\path\to\Cart-Crown' -Publish

The script safely refuses to switch branches when your local git checkout has uncommitted changes.
It checks out feature/iron-hills-five-mission-art-20261015, copies the PNGs,
verifies SHA-256 hashes, runs regression/type checks and pushes a single commit.
Your local git credentials must already allow pushing to the GitHub repo.

IF YOU ONLY WANT TO INSTALL LOCALLY, omit -Publish:
  .\publish_iron_hills_assets.ps1 -RepoPath 'C:\path\to\Cart-Crown'

Older install_iron_hills_assets.ps1 also remains included.

Once the files are pushed, GitHub CI/Android validation can run on PR #176.
Do not merge before both checks complete successfully.
