Cart & Crown pending unique unit art bundle

All runtime files are 256x256 transparent PNGs.

Human uniques:
- Shield Spearman -> assets/units/human_uniques/shield_spearman.png
- Ranger -> assets/units/human_uniques/ranger.png
- Border Ranger -> assets/units/human_uniques/border_ranger.png
- Scout Rider -> assets/units/human_uniques/scout_rider.png
- Man-at-Arms -> assets/units/human_uniques/man_at_arms.png

Elf uniques:
- Moon Ranger -> assets/units/elf_uniques/moon_ranger.png
- Forest Scout -> assets/units/elf_uniques/forest_scout.png
- Stag Rider -> assets/units/elf_uniques/stag_rider.png
- Spiritkeeper -> assets/units/elf_uniques/spiritkeeper.png
- Stag Lancer -> assets/units/elf_uniques/stag_lancer.png

Orc uniques:
- Youngblood -> assets/units/orc_uniques/youngblood.png
- Axe Thrower -> assets/units/orc_uniques/axe_thrower.png
- Bone Hunter -> assets/units/orc_uniques/bone_hunter.png
- Warg Rider -> assets/units/orc_uniques/warg_rider.png
- Warg Raider -> assets/units/orc_uniques/warg_raider.png
- Warg Lancer -> assets/units/orc_uniques/warg_lancer.png
