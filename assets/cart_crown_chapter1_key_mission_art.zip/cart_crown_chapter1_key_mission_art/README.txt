Cart & Crown — Chapter 1 key mission art

Optimized opaque JPEG runtime scenes, 512x288 (16:9).

Mappings:
- node_1 / A Banner Still Flies -> a_banner_still_flies.jpg
- node_4 / Spears at Dawn -> spears_at_dawn.jpg
- node_7 / Reclaim the Outpost -> reclaim_the_outpost.jpg

The remaining Chapter 1 missions continue using their existing type-based fallback art.
